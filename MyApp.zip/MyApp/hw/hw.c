void hwInit(void){
    
}